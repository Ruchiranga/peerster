import sys
import random

z = int(sys.argv[1])

print(random.randint(0, z))
